import os
#import requests
import json

# Fetch the API key from an environment variable for security
API_KEY = os.getenv("AI_API_KEY", "your_default_api_key_here")
API_URL = "https://api.ai-provider.com/v1/chat/completions"

def read_file(file_path):
    """
    Reads and returns the content of a file.
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    except FileNotFoundError:
        return f"Error: File '{file_path}' not found."
    except Exception as e:
        return f"Error reading file '{file_path}': {e}"

def send_request(cwe_file_path, context_file_path, additional_prompt=""):
    """
    Sends a request to a generative AI model with two files and returns the response.
    
    Args:
        cwe_file_path: Path to the file containing CWE findings
        context_file_path: Path to the file containing context information
        additional_prompt: Optional additional instructions for the model
    """
    if not API_KEY or API_KEY == "your_default_api_key_here":
        return "Error: AI_API_KEY environment variable not set. Please set it to your API key."

    # Read the files
    cwe_content = read_file(cwe_file_path)
    context_content = read_file(context_file_path)
    
    # Check if file reading was successful
    if cwe_content.startswith("Error:") or context_content.startswith("Error:"):
        return f"{cwe_content}\n{context_content}"

    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }

    system_prompt = """You are an expert security analyst specializing in evaluating potential false positives in CWE (Common Weakness Enumeration) findings.

CRITICAL INSTRUCTIONS:
- Do NOT hallucinate or make up any data, code snippets, or information
- Only provide analysis based strictly on the information provided in the CWE findings and context files
- If you are not 100% certain about any aspect of your evaluation, explicitly state your uncertainty
- If there is insufficient information to make a determination, clearly state what information is missing
- Do not write anything if you cannot verify it from the provided files
- Base your conclusions solely on evidence present in the provided materials

Your task is to:
1. Carefully analyze the CWE findings provided
2. Review the context information to understand the code and environment
3. Evaluate whether each finding is a true positive or a false positive
4. Provide clear reasoning for your assessment based only on the evidence provided
5. Highlight any areas where you lack sufficient information to make a confident determination"""

    user_message = f"""Please evaluate the following CWE findings for potential false positives.

=== CWE FINDINGS ===
{cwe_content}

=== CONTEXT INFORMATION ===
{context_content}

{additional_prompt if additional_prompt else ""}

Please provide your analysis, clearly stating for each finding whether it appears to be a true positive or false positive, and explain your reasoning based solely on the information provided."""

    data = {
        "model": "gpt-4-turbo",  # Or any other model
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message}
        ],
        "temperature": 0.1  # Lower temperature for more focused, deterministic responses
    }

    print(f"Sending request to {API_URL}...")
    
    # In a real scenario, you would make the network request like this:
    # try:
    #   response = requests.post(API_URL, headers=headers, json=data)
    #   response.raise_for_status()  # Raise an exception for bad status codes
    #   return response.json()["choices"][0]["message"]["content"]
    # except requests.exceptions.RequestException as e:
    #   return f"Error: API request failed - {e}"

    # For this demonstration, we'll return a mocked response.
    mock_response = {
        "choices": [
            {
                "message": {
                    "role": "assistant",
                    "content": "This is a mocked AI response. The API call was not actually made.\n\nIn a real scenario, the model would analyze the CWE findings against the provided context."
                }
            }
        ]
    }
    
    print("Received mocked response.")
    return mock_response["choices"][0]["message"]["content"]

if __name__ == "__main__":
    # Example file paths
    #cwe_file = "cwe_findings.txt"
    #context_file = "code_context.txt"
    
    # Optional additional instructions
   # additional_instructions = "Focus particularly on SQL injection and XSS vulnerabilities."
    
    # Get the response
   # ai_response = send_request(cwe_file, context_file, additional_instructions)
    
    # Print the response
   # print(f"\n{'='*60}")
   ## print("AI EVALUATION RESPONSE:")
    #print('='*60)
    #print(ai_response)
    print("Hello I am reqs")