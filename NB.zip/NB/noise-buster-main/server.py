import http.server
import socketserver
import json
import os
from functools import partial

# Mock backend scripts
def mock_filter_cves():
    print("filter_cves.py: Filtering complete (mocked).")
    return {"status": "success", "message": "CVEs filtered successfully."}

def mock_ai_request():
    print("ai_request.py: AI analysis complete (mocked).")
    return {"status": "success", "message": "AI analysis complete."}

class MyHttpRequestHandler(http.server.SimpleHTTPRequestHandler):
    """
    Custom handler to serve a React frontend and handle API requests.
    """

    def do_GET(self):
        # Handle API GET requests (useful for testing connection in browser)
        if self.path == '/api/analyze':
            # --- ADDED PRINT STATEMENT HERE ---
            print(f"Received GET request on {self.path} - Returning status check.") 
            mock_filter_cves()
            mock_ai_request()
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            # Return a status message for GET
            response = {"status": "online", "message": "API is running. Send a POST request with data to perform analysis."}
            self.wfile.write(json.dumps(response).encode('utf-8'))
        else:
            # Fallback to default behavior (serving static files like index.html)
            super().do_GET()

    def do_POST(self):
        # Handle API POST requests
        if self.path == '/api/analyze':
            print(f"Received POST request on {self.path} - Starting analysis...")
            
            # For simplicity, we're not processing the uploaded file content here.
            # We'll just call the mocked backend functions.
            
            # These functions contain the print statements you were looking for
            filter_result = mock_filter_cves()
            ai_result = mock_ai_request()
            print("HIIII")
            # Create a mock analysis result
            response_data = {
                "summary": {
                    "total_findings": 10,
                    "true_positives": 3,
                    "false_positives": 7,
                },
                "findings": [
                    {"id": "CVE-2023-1234", "description": "A sample vulnerability", "status": "True Positive"},
                    {"id": "CVE-2023-5678", "description": "Another sample vulnerability", "status": "False Positive"},
                ]
            }
            
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*') # Allow requests from the frontend
            self.end_headers()
            self.wfile.write(json.dumps(response_data).encode('utf-8'))
        else:
            # Handle 404 for unknown POST endpoints
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b'Not Found')

    def do_OPTIONS(self):
        # Handle CORS preflight requests
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type')
        self.end_headers()

# Configuration
PORT = 8000

# Define the directory to serve static files from (the frontend build)
# Adjust 'noise-buster-ui' and 'dist' to match your actual folder structure
# Using abspath to ensure correct path resolution
web_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'noise-buster-ui', 'dist')

# Ensure the directory exists to prevent immediate crash
if not os.path.exists(web_dir):
    print(f"Warning: Directory not found: {web_dir}")
    print("Serving from current directory instead for testing.")
    web_dir = os.path.dirname(os.path.abspath(__file__))

# Create the handler with the specific directory
Handler = partial(MyHttpRequestHandler, directory=web_dir)

# Start the server
print(f"Serving frontend from: {web_dir}")
print(f"Serving API at: http://localhost:{PORT}/api/analyze")

# Allow address reuse to prevent "Address already in use" errors on restart
socketserver.TCPServer.allow_reuse_address = True

with socketserver.TCPServer(("", PORT), Handler) as httpd:
    print(f"Server started at port {PORT}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping server...")
        httpd.shutdown()