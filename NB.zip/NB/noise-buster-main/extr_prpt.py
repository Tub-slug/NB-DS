import json

# Load the JFrog Xray JSON output
input_path = "/mnt/data/Build_Docker Image CI-4_Security_Export.json"
output_path = "/mnt/data/Extracted_Application_Properties.json"

with open(input_path, "r") as file:
    data = json.load(file)

# Initialize result dictionary with all properties
result = {
    "Type of application": "",
    "Operating system": "",
    "Programming language": "",
    "Framework": "",
    "Docker / Containerization": "",
    "CI/CD Pipeline": "",
    "Usage of the library": "",
    "Version and library configuration": "",
    "Network Exposure": "",
    "SBOM": ""
}

# Extract what we can infer from the file
# We know from the data that it's a Docker image analyzed by Xray
if "data" in data:
    components = data["data"]
    if any("Docker Image" in c.get("component_id", "") or "Docker" in c.get("component_id", "") or "build://Docker" in str(c.get("component_id", "")) for c in components):
        result["Docker / Containerization"] = "Docker image detected via build://Docker reference"
    
    # Programming language appears to be Python (pkg_type = "pypi")
    if any(c.get("pkg_type") == "pypi" for c in components):
        result["Programming language"] = "Python"
    
    # Framework: Django detected among components
    if any(c.get("component", "").lower() == "django" for c in components):
        result["Framework"] = "Django"
    
    # Libraries used
    libs = sorted(set(c.get("component", "") for c in components if c.get("component")))
    if libs:
        result["Usage of the library"] = ", ".join(libs)
    
    # Version and library configuration (summarize known versions)
    versions = {c.get("component"): c.get("source_comp_id") for c in components if c.get("component") and c.get("source_comp_id")}
    if versions:
        result["Version and library configuration"] = json.dumps(versions, indent=2)
    
    # Type of application - since Django appears, likely a web application
    if "Django" in result["Framework"]:
        result["Type of application"] = "Web application"
    
    # CI/CD pipeline: inferred from filename ("Build_Docker Image CI-4") and build://Docker reference
    result["CI/CD Pipeline"] = "JFrog Xray scan of CI build (likely automated pipeline)"
    
    # Network exposure: some vulnerabilities mention "remote attackers", "network", "HTTP", etc.
    if any("network" in c.get("high_profile_info", {}).get("FullDescription", "").lower() for c in components if c.get("high_profile_info")):
        result["Network Exposure"] = "Network-exposed application components detected (e.g., Django, AsyncSSH, urllib3)"
    
    # SBOM - the entire file acts as a software bill of materials
    result["SBOM"] = "Contained in this JFrog Xray JSON export"

# Write results to new JSON file
with open(output_path, "w") as outfile:
    json.dump(result, outfile, indent=2)

output_path
