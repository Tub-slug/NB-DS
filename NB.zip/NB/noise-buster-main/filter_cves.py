# -*- coding: utf-8 -*-
import json
import argparse
import logging
import re

# Nastavenie základného logovania
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class CVEFilter:
    """
    Trieda pre filtrovanie CVE (Common Vulnerabilities and Exposures) na základe
    definovaných pravidiel a kontextu aplikácie. Cieľom je redukovať "šum"
    a zamerať sa na relevantné zraniteľnosti.
    """

    def __init__(self, rules_path):
        """
        Inicializuje filter a načíta pravidlá z poskytnutého súboru.

        :param rules_path: Cesta k súboru s pravidlami pre filtrovanie.
        """
        self.rules = self._parse_rules(rules_path)
        logging.info(f"Pravidlá úspešne načítané z {rules_path}")

    def _parse_rules(self, rules_path):
        """
        Spracuje súbor s pravidlami a transformuje ho do štruktúrovanej podoby.
        Táto metóda načíta textový súbor a extrahuje z neho kľúčové slová pre filtrovanie.
        
        Poznámka: Parser je zjednodušený a zameriava sa na kľúčové slová
        identifikované v `cveFilteringWithoutAI.txt`.

        :param rules_path: Cesta k súboru s pravidlami.
        :return: Slovník so spracovanými pravidlami.
        """
        rules = {
            "non_web_app_vulns": set(),
            "lang_specific_vulns": {}
        }
        try:
            with open(rules_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # Pravidlo pre non-web aplikácie
            non_web_match = re.search(r"ak hocico okrem web app:\s*(.*)", content)
            if non_web_match:
                vulns = [v.strip().lower() for v in non_web_match.group(1).split(',')]
                rules["non_web_app_vulns"] = set(vulns)

            # Pravidlá špecifické pre programovacie jazyky
            lang_matches = re.findall(r"ak ([\w\s,./#]+):\s*(.*)", content)
            for match in lang_matches:
                langs = [l.strip().lower() for l in match[0].split(',')]
                vulns = [v.strip().lower() for v in match[1].split(',')]
                for lang in langs:
                    if lang not in rules["lang_specific_vulns"]:
                        rules["lang_specific_vulns"][lang] = set()
                    rules["lang_specific_vulns"][lang].update(vulns)
            
            return rules
        except FileNotFoundError:
            logging.error(f"Súbor s pravidlami nebol nájdený na ceste: {rules_path}")
            return rules # Vráti prázdne pravidlá

    def filter_cves(self, cves, context):
        """
        Hlavná metóda na filtrovanie zoznamu CVE.

        :param cves: Zoznam CVE záznamov (slovníkov) na filtrovanie.
        :param context: Slovník s kontextom aplikácie (napr. 'app_type', 'language').
        :return: Zoznam CVE, ktoré prešli filtrom.
        """
        if not isinstance(cves, list):
            logging.error("Vstupné CVEs nie sú v očakávanom formáte (zoznam).")
            return []

        filtered_cves = []
        for cve in cves:
            if self._should_keep_cve(cve, context):
                filtered_cves.append(cve)
        
        logging.info(f"Filtrovanie dokončené. Ponechaných {len(filtered_cves)} z {len(cves)} CVEs.")
        return filtered_cves

    def _should_keep_cve(self, cve, context):
        """
        Rozhodne, či má byť dané CVE ponechané alebo odfiltrované na základe pravidiel.

        :param cve: Jeden CVE záznam (slovník).
        :param context: Slovník s kontextom aplikácie.
        :return: True, ak má byť CVE ponechané, inak False.
        """
        app_type = context.get("app_type", "web app").lower()
        language = context.get("language", "").lower()

        # Získanie relevantných polí z CVE
        # Štruktúra CVE sa môže líšiť, toto je pokus o robustný prístup
        vuln_type = cve.get("high_profile_info", {}).get("VulnerabilityType", "").lower()
        summary = cve.get("summary", "").lower()
        severity = cve.get("severity", "Unknown").lower()

        # Pravidlo 1: Filtrovanie na základe typu aplikácie
        if app_type != "web app":
            if any(rule in vuln_type for rule in self.rules["non_web_app_vulns"]):
                logging.debug(f"Filtrujem CVE (ID: {cve.get('issue_id', 'N/A')}) kvôli typu aplikácie '{app_type}' a typu zraniteľnosti '{vuln_type}'.")
                return False

        # Pravidlo 2: Filtrovanie na základe programovacieho jazyka
        if language in self.rules["lang_specific_vulns"]:
            lang_rules = self.rules["lang_specific_vulns"][language]
            if any(rule in summary for rule in lang_rules):
                logging.debug(f"Filtrujem CVE (ID: {cve.get('issue_id', 'N/A')}) kvôli jazyku '{language}' a kľúčovému slovu v zhrnutí.")
                return False

        # Pravidlo 3: Filtrovanie na základe závažnosti (príklad ďalšieho robustného pravidla)
        # Ponecháme len zraniteľnosti so závažnosťou Critical, High, Medium
        if severity not in ["critical", "high", "medium"]:
            logging.debug(f"Filtrujem CVE (ID: {cve.get('issue_id', 'N/A')}) kvôli nízkej závažnosti '{severity}'.")
            return False

        # Pravidlo 4: Filtrovanie na základe dostupnosti opravy (príklad)
        # Ak komponenty nemajú žiadnu fix_versions, môžeme to považovať za menej akčné.
        # Táto logika je zjednodušená a závisí od presnej štruktúry dát.
        # Pre ukážku ju neimplementujeme priamo, ale naznačujeme možnosť.

        return True


def main():
    """
    Hlavná funkcia pre spustenie skriptu z príkazového riadku.
    Umožňuje testovanie filtra s konkrétnym JSON súborom a pravidlami.
    """
    parser = argparse.ArgumentParser(description="Filtruje CVE zraniteľnosti na základe kontextu a pravidiel.")
    parser.add_argument("json_file", help="Cesta k JSON súboru so zoznamom CVEs (napr. 'Build_Docker Image CI-4_Violations_Export.json').")
    parser.add_argument("rules_file", help="Cesta k súboru s pravidlami (napr. 'cveFilteringWithoutAI.txt').")
    parser.add_argument("--app-type", default="web app", help="Typ aplikácie (napr. 'web app', 'cli').")
    parser.add_argument("--language", default="python", help="Programovací jazyk aplikácie.")
    parser.add_argument("--output-file", help="Cesta k výstupnému JSON súboru. Ak nie je zadaná, výstup ide na štandardný výstup.")
    
    args = parser.parse_args()
    
    try:
        with open(args.json_file, 'r', encoding='utf-8') as f:
            # Načítame celý objekt a predpokladáme, že zraniteľnosti sú v kľúči, 
            # alebo je to priamo zoznam. Pre 'Violations_Export.json' je to priamo zoznam.
            cves_data = json.load(f)
    except FileNotFoundError:
        logging.error(f"Vstupný JSON súbor nebol nájdený: {args.json_file}")
        return
    except json.JSONDecodeError:
        logging.error(f"Chyba pri dekódovaní JSON súboru: {args.json_file}")
        return

    # Inicializácia filtra
    cve_filter = CVEFilter(args.rules_file)

    # Príprava kontextu
    context = {
        "app_type": args.app_type,
        "language": args.language
    }
    
    # Filtrovanie
    filtered_cves = cve_filter.filter_cves(cves_data, context)
    
    # Výstup
    output_json = json.dumps(filtered_cves, indent=4)
    
    if args.output_file:
        with open(args.output_file, 'w', encoding='utf-8') as f:
            f.write(output_json)
        logging.info(f"Výsledky boli zapísané do súboru: {args.output_file}")
    else:
        print(output_json)


if __name__ == "__main__":
    main()