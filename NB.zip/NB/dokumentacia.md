# Dokumentácia projektu Noise Buster

Tento dokument poskytuje technický prehľad kľúčových komponentov backendu projektu Noise Buster.

## 1. Filter zraniteľností (`filter_cves.py`)

Tento skript slúži ako hlavný nástroj na inteligentné filtrovanie a redukciu zraniteľností (CVEs) nahlásených bezpečnostnými skenermi. Jeho cieľom je znížiť "šum" a umožniť bezpečnostným analytikom sústrediť sa na relevantné hrozby.

### 1.1. Architektúra a dizajn

Skript je navrhnutý s ohľadom na modularitu a rozšíriteľnosť. Hlavnou komponentou je trieda `CVEFilter`.

#### Trieda `CVEFilter`

Zapuzdruje všetku logiku potrebnú na načítanie pravidiel, spracovanie a filtrovanie zraniteľností.

- **`__init__(self, rules_path)`**
  - Konštruktor triedy.
  - Prijíma cestu k súboru s pravidlami (`cveFilteringWithoutAI.txt`).
  - Volá metódu `_parse_rules` na spracovanie pravidiel a uloží ich do inštančnej premennej `self.rules`.

- **`_parse_rules(self, rules_path)`**
  - **Kľúčová metóda pre dynamické načítanie pravidiel.**
  - Otvorí a prečíta súbor s pravidlami.
  - Pomocou regulárnych výrazov extrahuje pravidlá pre:
    - **Non-web aplikácie**: Identifikuje zraniteľnosti (napr. XSS, CSRF), ktoré sú irelevantné pre aplikácie, ktoré nie sú webového charakteru.
    - **Špecifické programovacie jazyky**: Identifikuje typy zraniteľností (napr. "buffer overflow"), ktoré sa nevzťahujú na určité jazyky (napr. Python, Java).
  - Ukladá pravidlá do štruktúrovaného slovníka pre rýchly prístup.

- **`filter_cves(self, cves, context)`**
  - Hlavná verejná metóda, ktorá prijíma zoznam CVEs a kontext aplikácie.
  - Iteruje cez každé CVE a volá `_should_keep_cve` na rozhodnutie, či sa má ponechať.
  - Vráti nový zoznam, ktorý obsahuje iba relevantné zraniteľnosti.

- **`_should_keep_cve(self, cve, context)`**
  - Súkromná metóda, kde je implementovaná samotná logika filtrovania.
  - Pre každé CVE postupne aplikuje nasledujúce pravidlá:
    1.  **Filtrovanie podľa typu aplikácie**: Ak kontext `app_type` nie je "web app", skontroluje, či typ zraniteľnosti zodpovedá pravidlám pre non-web aplikácie.
    2.  **Filtrovanie podľa jazyka**: Ak je v kontexte definovaný `language`, skontroluje, či sa v popise zraniteľnosti nachádzajú kľúčové slová definované v pravidlách pre daný jazyk.
    3.  **Filtrovanie podľa závažnosti**: Ponechá iba zraniteľnosti so závažnosťou `Critical`, `High` alebo `Medium`. Ostatné (napr. `Low`, `Info`) sú odfiltrované.
  - Ak CVE prejde všetkými kontrolami, metóda vráti `True`.

### 1.2. Spustenie a použitie

Skript je možné spustiť priamo z príkazového riadku, čo je užitočné pre testovanie a samostatné analýzy.

```bash
python noise-buster-main/filter_cves.py <cesta_k_json> <cesta_k_pravidlam> [voliteľné_parametre]
```

**Príklad:**

```bash
python noise-buster-main/filter_cves.py "noise-buster-main/Build_Docker Image CI-4_Violations_Export.json" "noise-buster-main/cveFilteringWithoutAI.txt" --language python --output-file filtered_results.json
```

**Argumenty:**
- `json_file`: Povinný. Cesta k JSON súboru so zraniteľnosťami.
- `rules_file`: Povinný. Cesta k `cveFilteringWithoutAI.txt`.
- `--app-type`: Voliteľný. Typ aplikácie (napr. `web app`, `cli`). Predvolená hodnota je `web app`.
- `--language`: Voliteľný. Programovací jazyk (napr. `python`, `java`).
- `--output-file`: Voliteľný. Súbor, do ktorého sa zapíše výsledok. Ak sa nezadá, výstup sa vypíše na konzolu.

---

## 2. HTTP Server (`server.py`)

Tento skript spúšťa jednoduchý HTTP server, ktorý slúži ako backend pre webové rozhranie projektu a zároveň poskytuje API endpointy na analýzu dát.

### 2.1. Architektúra a dizajn

Server je postavený na štandardných Python knižniciach `http.server` a `socketserver`.

#### Trieda `MyHttpRequestHandler`

Vlastný handler, ktorý rozširuje `http.server.SimpleHTTPRequestHandler` a definuje správanie pre rôzne typy HTTP požiadaviek.

- **`do_GET(self)`**
  - Spracováva GET požiadavky.
  - Ak je požiadavka na `/api/analyze`, vráti JSON odpoveď so statusom API, čo je užitočné na overenie, či server beží.
  - Pre všetky ostatné cesty sa správa ako štandardný `SimpleHTTPRequestHandler` a servíruje statické súbory (napr. `index.html` z `noise-buster-ui/dist`).

- **`do_POST(self)`**
  - Spracováva POST požiadavky.
  - Endpoint `/api/analyze` je určený na spustenie analýzy.
  - **Dôležité**: V súčasnej verzii sú volania na `filter_cves.py` a `ai_request.py` **mockované** (nahradené atrapami `mock_filter_cves()` a `mock_ai_request()`).
  - V produkčnej verzii by sa na tomto mieste importovala trieda `CVEFilter` z `filter_cves.py`, vytvorila by sa jej inštancia a zavolala by sa metóda `filter_cves` s dátami z POST požiadavky.
  - Po analýze vráti mockované výsledky vo formáte JSON.

- **`do_OPTIONS(self)`**
  - Spracováva `OPTIONS` požiadavky, ktoré sú nevyhnutné pre správne fungovanie CORS (Cross-Origin Resource Sharing).
  - Umožňuje frontendovej aplikácii (bežiacej na inom porte) bezpečne komunikovať s týmto serverom.

### 2.2. Konfigurácia a spustenie

- **Port**: Server je nakonfigurovaný na spustenie na porte `8000`.
- **Servírovanie frontendu**: Server je nastavený tak, aby servíroval statické súbory z priečinka `../noise-buster-ui/dist`. To znamená, že očakáva, že build frontendovej aplikácie je v tomto umiestnení.
- **Spustenie**: Server sa spúšťa štandardným príkazom:
  ```bash
  python noise-buster-main/server.py
  ```

### 2.3. Integrácia a ďalší vývoj

Pre plnú funkčnosť je potrebné nahradiť mockované volania v `do_POST` metode reálnou implementáciou:

1.  **Importovať `CVEFilter`** z `filter_cves.py`.
2.  Načítať dáta (JSON so zraniteľnosťami a kontext) z tela POST požiadavky.
3.  Vytvoriť inštanciu `cve_filter = CVEFilter("cesta/k/pravidlam.txt")`.
4.  Zavolať `filtered_cves = cve_filter.filter_cves(data, context)`.
5.  Výsledok `filtered_cves` poslať (voliteľne) na ďalšiu analýzu do `ai_request.py`.
6.  Finálne výsledky poslať ako JSON odpoveď klientovi.
