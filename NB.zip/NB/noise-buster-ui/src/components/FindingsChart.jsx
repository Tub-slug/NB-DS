// src/components/FindingsChart.jsx
import React from "react";
import { cardStyleBase } from "../styles";
import { Bar } from "react-chartjs-2";
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Tooltip,
    Legend,
} from "chart.js";

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip, Legend);

export default function FindingsChart({ summary }) {
    if (!summary) return null;

    const labels = ["Critical", "High", "Medium", "Low"];
    const dataValues = [
        summary.critical || 0,
        summary.high || 0,
        summary.medium || 0,
        summary.low || 0,
    ];

    const data = {
        labels,
        datasets: [
            {
                label: "Findings count",
                data: dataValues,
                backgroundColor: [
                    "#ff4d4f",   // Critical
                    "#ff9966",   // High
                    "#ffd666",   // Medium
                    "#5bc0de",   // Low
                ],
                borderColor: [
                    "#ff4d4f",
                    "#ff9966",
                    "#ffd666",
                    "#5bc0de",
                ],
                borderWidth: 1,
                borderRadius: 4,
                barThickness: 40,
            },
        ],
    };

    const options = {
        responsive: true,
        maintainAspectRatio: false, // ми самі контролюємо висоту
        scales: {
            x: {
                ticks: {
                    color: "#fff",
                    font: { size: 12 },
                },
                grid: {
                    color: "rgba(255,255,255,0.1)",
                },
            },
            y: {
                beginAtZero: true,
                ticks: {
                    color: "#fff",
                    font: { size: 12 },
                },
                grid: {
                    color: "rgba(255,255,255,0.1)",
                },
            },
        },
        plugins: {
            legend: {
                display: false, // ховаємо легенду => не можна клікати і вимикати серію
            },
            tooltip: {
                backgroundColor: "#000",
                titleColor: "#fff",
                bodyColor: "#fff",
                borderColor: "#444",
                borderWidth: 1,
            },
        },
    };

    const titleStyle = {
        fontSize: "16px",
        fontWeight: 600,
        color: "#fff",
        marginBottom: "16px",
        textAlign: "center",
    };

    return (
        <div style={{ ...cardStyleBase, textAlign: "center" }}>
            <div style={titleStyle}>Severity distribution</div>

            <div style={{ width: "100%", height: "200px" }}>
                <Bar data={data} options={options} />
            </div>
        </div>
    );
}
