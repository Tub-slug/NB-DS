// src/components/UploadPanel.jsx
import React, { useRef, useState } from "react";
import { uploadFile, getResult, DEMO_MODE } from "../api";
import { cardStyleBase } from "../styles";

export default function UploadPanel({ onResultReady }) {
    // selected file object
    const [file, setFile] = useState(null);
    const fileInputRef = useRef(null);

    // "idle" | "uploading" | "processing" | "done" | "error"
    const [status, setStatus] = useState("idle");

    const statusTextMap = {
        idle: "Waiting for file...",
        uploading: "Uploading file...",
        processing: "Analyzing (Noise Buster is reducing noise)...",
        done: "Analysis complete.",
        error: "Error during upload or analysis.",
    };

    const progressPercent = {
        idle: 0,
        uploading: 30,
        processing: 70,
        done: 100,
        error: 0,
    }[status] || 0;

    function handleChooseClick() {
        fileInputRef.current?.click();
    }

    function handleFileSelected(e) {
        const f = e.target.files[0];
        if (f) {
            setFile(f);
        }
    }

    async function handleUploadClick(e) {
        e.preventDefault(); // не перезавантажуй сторінку

        if (!file) {
            alert("Please select a .zip export first.");
            return;
        }

        try {
            setStatus("uploading");

            const result = await uploadFile(file);
            setStatus("done");
            onResultReady(result);
        } catch (err) {
            console.error(err);
            setStatus("error");
        }
    }

    // Локальні стилі елементів усередині картки
    const headerBlock = {
        textAlign: "center",
        marginBottom: "16px",
    };

    const headerTitle = {
        textTransform: "none",
        fontSize: "14px",
        fontWeight: 600,
        color: "#fff",
        marginBottom: "8px",
    };

    const headerDesc = {
        fontSize: "13px",
        lineHeight: 1.4,
        color: "#ccc",
        fontWeight: 400,
    };

    const buttonCommon = {
        width: "100%",
        background: "#444",
        color: "#fff",
        border: "1px solid #000",
        borderRadius: "6px",
        padding: "10px 12px",
        fontSize: "14px",
        cursor: "pointer",
        fontWeight: 500,
        textAlign: "center",
    };

    const analyzeButton = {
        ...buttonCommon,
        background:
            status === "processing" || status === "uploading" ? "#444" : "#000",
        fontSize: "15px",
        fontWeight: 600,
        cursor:
            status === "processing" || status === "uploading"
                ? "wait"
                : "pointer",
    };

    const progressOuter = {
        background: "#e5e5e5",
        borderRadius: "4px",
        height: "6px",
        overflow: "hidden",
        marginTop: "16px",
        marginBottom: "16px",
    };

    const progressInner = {
        height: "100%",
        width: `${progressPercent}%`,
        background:
            status === "error"
                ? "#d9534f"
                : "linear-gradient(#00c6ff,#0072ff)",
        transition: "width 0.4s ease",
    };

    const infoRow = {
        fontSize: "13px",
        color: "#ccc",
        lineHeight: 1.5,
        textAlign: "center",
    };

    const badgeDone = {
        display: "inline-block",
        background: "#2d6a2d",
        color: "#fff",
        borderRadius: "4px",
        padding: "3px 6px",
        fontSize: "12px",
        fontWeight: 600,
    };

    return (
        <div style={{ ...cardStyleBase, textAlign: "center" }}>
            {/* захований нативний file input */}
            <input
                ref={fileInputRef}
                type="file"
                accept=".zip,application/zip"
                onChange={handleFileSelected}
                style={{ display: "none" }}
            />

            {/* Заголовок + опис */}
            <div style={headerBlock}>
                <div
                    style={{
                        textTransform: "uppercase",
                        fontSize: "11px",
                        fontWeight: 500,
                        color: "#999",
                        letterSpacing: "0.05em",
                        marginBottom: "8px",
                    }}
                >
                    Upload scan
                </div>

                <div style={headerTitle}>
                    Upload SCA export (.zip). Noise Buster will analyze CVEs and
                    filter out false positives.
                </div>

                <div style={headerDesc}>
                    Then we’ll assign relevance for your environment.
                </div>
            </div>

            {/* Кнопки */}
            <div
                style={{
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "stretch",
                    gap: "8px",
                }}
            >
                <button
                    type="button"
                    onClick={handleChooseClick}
                    style={buttonCommon}
                >
                    {file ? `Selected: ${file.name}` : "Choose .zip file"}
                </button>

                <button
                    type="button"
                    onClick={handleUploadClick}
                    style={analyzeButton}
                    disabled={status === "processing" || status === "uploading"}
                >
                    {status === "processing" || status === "uploading"
                        ? "Analyzing..."
                        : "Upload & Analyze"}
                </button>
            </div>

            {/* Прогрес-бар */}
            <div style={progressOuter}>
                <div style={progressInner} />
            </div>

            {/* Статус і Run ID */}
            <div style={infoRow}>
                <div style={{ marginTop: "4px" }}>
                    <strong>Status:</strong>{" "}
                    {status === "done" ? (
                        <span style={badgeDone}>Analysis complete.</span>
                    ) : (
                        statusTextMap[status] || status
                    )}
                </div>
            </div>
        </div>
    );
}
