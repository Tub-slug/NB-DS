// src/components/FindingsTable.jsx
import React from "react";
import { cardStyleBase } from "../styles";

function colorForSeverity(sev) {
    if (!sev) return "#ccc";
    const s = sev.toLowerCase();
    if (s === "critical") return "#ff4d4f";
    if (s === "high") return "#ff9966";
    if (s === "medium") return "#ffd666";
    if (s === "low") return "#5bc0de";
    return "#ccc";
}

export default function FindingsTable({ findings }) {
    const headerStyle = {
        textTransform: "uppercase",
        fontSize: "11px",
        fontWeight: 500,
        color: "#999",
        letterSpacing: "0.05em",
        marginBottom: "8px",
        textAlign: "left",
    };

    const titleStyle = {
        fontSize: "15px",
        fontWeight: 600,
        color: "#fff",
        marginBottom: "16px",
        textAlign: "left",
    };

    if (!findings || findings.length === 0) {
        return (
            <div style={{ ...cardStyleBase, marginBottom: "60px" }}>
                <div style={headerStyle}>Details</div>
                <div style={titleStyle}>Findings</div>
                <div style={{ color: "#aaa", fontSize: "13px" }}>No data.</div>
            </div>
        );
    }

    return (
        <div style={{ ...cardStyleBase, marginBottom: "60px" }}>
            <div style={headerStyle}>Details</div>
            <div style={titleStyle}>Findings</div>

            <div style={{ overflowX: "auto" }}>
                <table
                    style={{
                        width: "100%",
                        borderCollapse: "collapse",
                        minWidth: "700px",
                    }}
                >
                    <thead>
                    <tr style={{ borderBottom: "1px solid #444" }}>
                        <th
                            style={{
                                textAlign: "left",
                                padding: "8px 12px",
                                color: "#bbb",
                                fontWeight: 500,
                                fontSize: "13px",
                            }}
                        >
                            CVE
                        </th>
                        <th
                            style={{
                                textAlign: "left",
                                padding: "8px 12px",
                                color: "#bbb",
                                fontWeight: 500,
                                fontSize: "13px",
                            }}
                        >
                            Package
                        </th>
                        <th
                            style={{
                                textAlign: "left",
                                padding: "8px 12px",
                                color: "#bbb",
                                fontWeight: 500,
                                fontSize: "13px",
                            }}
                        >
                            Version
                        </th>
                        <th
                            style={{
                                textAlign: "left",
                                padding: "8px 12px",
                                color: "#bbb",
                                fontWeight: 500,
                                fontSize: "13px",
                            }}
                        >
                            Severity
                        </th>
                        <th
                            style={{
                                textAlign: "left",
                                padding: "8px 12px",
                                color: "#bbb",
                                fontWeight: 500,
                                fontSize: "13px",
                            }}
                        >
                            CVSS
                        </th>
                        <th
                            style={{
                                textAlign: "left",
                                padding: "8px 12px",
                                color: "#bbb",
                                fontWeight: 500,
                                fontSize: "13px",
                            }}
                        >
                            Relevant in env?
                        </th>
                    </tr>
                    </thead>
                    <tbody>
                    {findings.map((f, i) => (
                        <tr
                            key={i}
                            style={{
                                borderBottom: "1px solid #333",
                            }}
                        >
                            <td style={{ padding: "8px 12px", color: "#fff" }}>
                                {f.cve}
                            </td>
                            <td style={{ padding: "8px 12px", color: "#fff" }}>
                                {f.package}
                            </td>
                            <td style={{ padding: "8px 12px", color: "#fff" }}>
                                {f.version}
                            </td>
                            <td
                                style={{
                                    padding: "8px 12px",
                                    color: colorForSeverity(f.severity),
                                    fontWeight: 600,
                                }}
                            >
                                {f.severity}
                            </td>
                            <td style={{ padding: "8px 12px", color: "#fff" }}>
                                {f.cvss}
                            </td>
                            <td
                                style={{
                                    padding: "8px 12px",
                                    color: f.relevant ? "#5cb85c" : "#aaa",
                                    fontWeight: 600,
                                }}
                            >
                                {f.relevant ? "YES" : "no"}
                            </td>
                        </tr>
                    ))}
                    </tbody>
                </table>
            </div>

            <h4
                style={{
                    marginTop: "24px",
                    marginBottom: "8px",
                    fontSize: "13px",
                    fontWeight: 500,
                    color: "#bbb",
                    textAlign: "left",
                }}
            >
                Raw data (debug)
            </h4>
            <pre
                style={{
                    background: "#000",
                    padding: "12px",
                    borderRadius: "6px",
                    maxHeight: "180px",
                    overflowY: "auto",
                    fontSize: "12px",
                    color: "#0f0",
                }}
            >
        {JSON.stringify(findings, null, 2)}
      </pre>
        </div>
    );
}
