// src/components/SummaryCard.jsx
import React from "react";
import { cardStyleBase } from "../styles";

export default function SummaryCard({ summary }) {
    if (!summary) return null;

    const headerStyle = {
        textTransform: "uppercase",
        fontSize: "11px",
        fontWeight: 500,
        color: "#999",
        letterSpacing: "0.05em",
        textAlign: "left",
        marginBottom: "8px",
    };

    const titleStyle = {
        fontSize: "15px",
        fontWeight: 600,
        color: "#fff",
        marginBottom: "8px",
        textAlign: "left",
    };

    const subtitleStyle = {
        fontSize: "12px",
        color: "#aaa",
        textAlign: "left",
        lineHeight: 1.4,
        marginBottom: "16px",
    };

    const gridStyle = {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit,minmax(120px,1fr))",
        gap: "12px",
    };

    const labelStyle = { color: "#aaa", fontSize: "12px" };
    const valueStyle = (color) => ({
        fontSize: "18px",
        fontWeight: 600,
        color: color || "#fff",
    });

    return (
        <div style={cardStyleBase}>
            <div style={headerStyle}>Overview</div>

            <div style={titleStyle}>Analysis summary</div>

            <div style={subtitleStyle}>
                Findings after relevance filtering (environment-aware).
            </div>

            <div style={gridStyle}>
                <div>
                    <div style={labelStyle}>Total findings</div>
                    <div style={valueStyle()}>{summary.total_findings}</div>
                </div>

                <div>
                    <div style={labelStyle}>Critical</div>
                    <div style={valueStyle("#ff4d4f")}>{summary.critical}</div>
                </div>

                <div>
                    <div style={labelStyle}>High</div>
                    <div style={valueStyle("#ff9966")}>{summary.high}</div>
                </div>

                <div>
                    <div style={labelStyle}>Medium</div>
                    <div style={valueStyle("#ffd666")}>{summary.medium}</div>
                </div>

                <div>
                    <div style={labelStyle}>Low</div>
                    <div style={valueStyle("#5bc0de")}>{summary.low}</div>
                </div>
            </div>
        </div>
    );
}
