// src/styles.js

export const cardStyleBase = {
    background: "#1f1f1f",
    color: "#fff",
    borderRadius: "10px",
    padding: "20px 24px",
    margin: "24px auto",
    width: "100%",
    maxWidth: "800px",
    boxShadow:
        "0 24px 60px rgba(0,0,0,0.7), 0 2px 4px rgba(0,0,0,0.4)",
    border: "1px solid rgba(255,255,255,0.08)",
    fontSize: "14px",
    lineHeight: 1.4,
};
