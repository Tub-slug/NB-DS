// src/App.jsx
import React, { useState } from "react";
import "./App.css";

import UploadPanel from "./components/UploadPanel";
import SummaryCard from "./components/SummaryCard";
import FindingsChart from "./components/FindingsChart";
import FindingsTable from "./components/FindingsTable";

function App() {
    const [analysisResult, setAnalysisResult] = useState(null);

    return (
        <div className="app-root">
            <div className="app-inner">
                <h1 className="app-title">Noise Buster</h1>

                <div className="app-subtitle">
                    Multi-layer CVE relevance filter for SCA findings.
                    <br />
                    Less noise. More focus.
                </div>

                <div className="app-divider" />

                <UploadPanel onResultReady={setAnalysisResult} />

                {analysisResult && (
                    <>
                        <SummaryCard summary={analysisResult.summary} />
                        <FindingsChart summary={analysisResult.summary} />
                        <FindingsTable findings={analysisResult.findings} />
                    </>
                )}
            </div>
        </div>
    );
}

export default App;
