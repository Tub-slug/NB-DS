// src/api.js
import axios from "axios";

// If this is true, frontend will simulate backend responses.
// Set to false later when real backend is ready.
export const DEMO_MODE = false;

// This is where backend will live eventually.
const API_BASE = "http://localhost:8000";

// Simulate POST /upload
export async function uploadFile(file) {
    if (DEMO_MODE) {
        // pretend backend accepted the file and started processing
        return {
            run_id: "demo-run-123",
            status: "processing",
        };
    }

    const formData = new FormData();
    formData.append("file", file);

    const res = await axios.post(`${API_BASE}/api/analyze`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
    });

    return res.data;
}
